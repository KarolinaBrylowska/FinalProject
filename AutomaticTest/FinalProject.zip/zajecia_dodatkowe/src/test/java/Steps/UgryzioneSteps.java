package Steps;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class UgryzioneSteps {
    static WebDriver webDriver;

    @BeforeAll
    static public void setUp(){
        System.setProperty("webdriver.chrome.driver","/Users/karaolinabrylowska/Desktop/webDriver/chromedriver");
        webDriver=new ChromeDriver();
    }

    @When("Go to Ugryzione site")
    public void goToUgryzioneSite() {

        webDriver.navigate().to("https://ugryzione.pl/");
    } //otwarcie strony


    @And("Showed Home page with popup")
    public void showedHomePageWithPopup() {
    }

    @Then("Close pop up")
    public void closePopUp() {
        String selector="sgpb-popup-close-button-1";
        String selector01=("//div[2]/div/a");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {             // metoda do czekania przez określoną ilość czasu - ZAWSZE
            throw new RuntimeException(e);
        }
        webDriver.findElement(By.className(selector)).click(); //zamknięcie popupa z informacją o czasie oczekiwania
        webDriver.findElement(By.xpath(selector01)).click(); //zamknięcie paska dolnego z info o cookies
    }

    @When("Choose a SKLEP category")
    public void chooseACategory() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {             // metoda do czekania przez określoną ilość czasu
            throw new RuntimeException(e);
        }
        String selector2="//span[text()='SKLEP']";
        webDriver.findElement(By.xpath(selector2)).click(); //kliknięcie ikony SKLEP z menu głównego
    }

    @And("Click one item and add it to the cart x2")
    public void clickOneItemFromThatCategory() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {             // metoda do czekania przez określoną ilość czasu
            throw new RuntimeException(e);
        }
        String selector3=".product:nth-child(5) .button";
        webDriver.findElement(By.cssSelector(selector3)).click();//dodanie pierwszego produktu
        webDriver.findElement(By.cssSelector(selector3)).click();//dodanie drugiego produktu
    }


    @And("Go to the cart")
    public void iCanSeeMessageAboutThetNewItemWasAddedToTheCart() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {             // metoda do czekania przez określoną ilość czasu
            throw new RuntimeException(e);
        }
        String selector5=".fusion-main-menu-icon-active";
        webDriver.findElement(By.cssSelector(selector5)).click(); //kliknięcie koszyka zakupowego

    }

    @Then("Verify total price of products")
    public void verifyTotalPriceOfProducts() {
        String priceSelector=("//div[@id='post-33']/div/div/form/div/table/tbody/tr/td[4]");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {             // metoda do czekania przez określoną ilość czasu
            throw new RuntimeException(e);
        }
        String price = webDriver.findElement(By.xpath(priceSelector)).getText(); //paragraf pobierający cenę z koszyka zakupowego
        System.out.println("Total price is: " +price );
    }
    @AfterAll
    static public void tearDown(){
        webDriver.quit();
    }
}



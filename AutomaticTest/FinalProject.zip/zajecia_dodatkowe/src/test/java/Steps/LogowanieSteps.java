package Steps;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class LogowanieSteps {
    static WebDriver driver;

    @BeforeAll
    static public void setUp(){
        System.setProperty("webdriver.chrome.driver","/Users/karaolinabrylowska/Desktop/webDriver/chromedriver");
        driver=new ChromeDriver();
    }
    @Given("Uzytkownik jest na stronie logowania")
    public void uzytkownik_jest_na_stronie_logowania() {
        //System.setProperty("webdriver.chrome.driver","/Users/karaolinabrylowska/Desktop/webDriver/chromedriver");
       // driver=new ChromeDriver();
      //driver.get("https://the-internet.herokuapp.com/login");
        driver.navigate().to("https://the-internet.herokuapp.com/login");
    }
    @When("Uzytkownik wprowadza poprawny login")
    public void uzytkownik_wprowadza_poprawny_login() {
        driver.findElement(By.id("username")).sendKeys("tomsmith");
    }
    @And("Uzytkownik wprowadza poprawne haslo")
    public void uzytkownik_wprowadza_poprawne_haslo() {
        driver.findElement(By.name("password")).sendKeys("SuperSecretPassword!");

    }
    @And("Uzytkownik klika przycisk Login")
    public void uzytkownik_klika_przycisk_login() {
        driver.findElement(By.tagName("button")).click();

    }
    @Then("Uzytkownik zostal poprawnie zalogowany")
    public void uzytkownik_zostal_poprawnie_zalogowany() {
        Assert.assertEquals("https://the-internet.herokuapp.com/secure",driver.getCurrentUrl());
    }

    @AfterAll
    static public void tearDown(){
        driver.quit();
    }
}
